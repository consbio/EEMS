#!/opt/local/bin/python

# import the classes needed to create a version of EEMS
import re
import numpy as np
from EEMSBasePackage import EEMSCmdRunnerBase
from EEMSBasePackage import EEMSInterpreter

# Create the EEMSCmdRunner class, by overloading the
# necessary methods from the EEMSCmdRunnerBase class.
# An object of this class will be handed to the interpreter
# and allow EEMS to run.
class EEMSCmdRunner(EEMSCmdRunnerBase):
    def _WriteFldsToFiles(self):
        # Create a map of files and fields
        outFileMap = self._CreateOutFileMap()

        # Go through outFileMap and write the fields to each file
        for outFNm in outFileMap.keys():
            if outFNm != 'NONE':
                outFile = open(outFNm,'w')

                # write field names
                outFile.write(','.join(outFileMap[outFNm])+'\n')
                
                # write values to file
                outChunk = ''
                rowMax = 100000
                rowCnt = 0
                for rowNdx in range(self.arrayShape[0]): # unique to csv!
                    outVals = []
                    for fldNm in outFileMap[outFNm]:
                        outVals.append(self.EEMSFlds[fldNm]['data'][rowNdx])
                    outChunk += ','.join([str(x) for x in outVals])+'\n'
                    rowCnt += 1

                    if rowCnt >= rowMax:
                        outFile.write(outChunk)
                        outChunk = ''
                        rowCnt = 0
                # for rowNdx in range(self.arrayShape[0]): # unique to csv!

                outFile.write(outChunk)

                outFile.close()

    # def _WriteFldsToFile(self):

########################################################################
# Public methods
########################################################################

    def ReadMulti(
        self,
        inFileName,
        inFieldNames,
        outFileName
        ):

        inFile = open(inFileName,'rU')
        line = inFile.readline()
        line = line.rstrip('\r\f\n')
        line = re.sub('"','',line)

        fileFldNms = line.split(',')

        # Confirm all inFieldNames in input file
        for inFldNm in inFieldNames:
            if inFldNm not in fileFldNms:
                raise Exception(
                    '\n********************ERROR********************\n'+
                    'Cannot read field *%s* from file %s.\n'%(inFldNm,inFileName))
            
        # determine inFieldNames col ndxs in input file
        tmpColData = {}
        colNdx = 0
        for fileFldNm in fileFldNms:
            if fileFldNm in inFieldNames:
                tmpColData[fileFldNm] = {'colNdx':colNdx,'data':[]}
            colNdx += 1

        # Load in data from lines
        line = inFile.readline()

        while line != '':
            line = line.rstrip('\r\f\n')
            line = re.sub('"','',line)
            inTokens = line.split(',')

            for fldNm in tmpColData.keys():
                try:
                    fldVal = float(inTokens[tmpColData[fldNm]['colNdx']])
                except ValueError:
                    fldVal = float('nan')

                tmpColData[fldNm]['data'].append(fldVal)

            # for fldNm in tmpColData.keys():

            line = inFile.readline()

        # while line != '':

        # Add fields to EEMSFlds
        for fldNm in tmpColData.keys():
            self._AddFieldToEEMSFlds(outFileName,fldNm,np.array(tmpColData[fldNm]['data']))
                    
        inFile.close()

    # def ReadMulti(...)

    def Finish(self):
        self._WriteFldsToFiles()

# class EEMSCmdRunner(EEMSCmdRunnerBase):                                            
########################################################################

########################################################################
# EEMSArcModelRun.py
#
# Version of EEMS to run wih Arc.
#
# The strategy here is to start with an input feature class or 
# shapefile. From that delete the fields that will be generated
# by EEMS. Convert this into a .csv file. Run EEMS with that csv file
# as input and a second csv file as output. Take the output csv
# file, convert it into a geodatabase file, and then join this back
# to the input feature class or shapefile. This is done because it
# seems to be faster than doing the reads and rights on a feature
# class or shapefile.
#
# For this to work, CSVID must be present in the EEMS output file.
# EEMS for Arc requires an EEMSInit command which will put a READ
# command into the EEMS command file so that CSVID gets into the
# EEMS output csv file.
#
# By Mike Gough and Tim Sheehan
# Conservation Biology Institute
# www.consbio.org
#
# Revision History
#
# 2014.03.12 - tjs
#
# Initial coding finished. Debugging and testing needed.
#
########################################################################

import arcpy
import csv
import os
import tmpfile
import shutil
import time

inOutFCNm = arcpy.GetParameterAsText(0)
EEMSCmdFileNm = arcpy.GetParameterAsText(1)

tmpDNm = tmpfile.mkdtemp()

# Instantiate the EEMS interpreter
myInterp = EEMSInterpreter(EEMSCmdFileNm,EEMSCmdRunner())

# Delete output fields from the feature class
arcpy.AddMessage('Deleting Fields...\n')
arcpy.DeleteField_management(inOutFCNm, myInterp.GetAllResultNames())

# Create the CSV File that EEMS will read from
arcpy.AddMessage('Exporting feature class to CSV for input to EEMS...\n')
inTmpCsvFNm=tmpDNm+os.sep+"inTmp.csv"

inTmpCsvF=open(inTmpCsvFNm, 'wb')
rows = arcpy.SearchCursor(inOutFCNm)
csvFile = csv.writer(outCSVF) 
fieldNms = [f.name for f in arcpy.ListFields(inputFC)]

allRows = []
for row in rows:
    rowlist = []
    for fieldNm in fieldNms:
        rowlist.append(row.getValue(fieldNm))
    allRows.append(rowlist)

fieldnames[0]='CSVID'

csvFile.writerow(fieldNms)
for row in allRows:
    csvFile.writerow(row)

csvFile.close()

inTmpCsvFNm
# Run EEMS on csv file
outTmpCsvFNm = tmpDNm+os.sep+"outTmp.csv"

# Overrides to a i/o done on temp csv files
myInterp.SetOverrideParam('outFileName',outTmpCsvFNm)
myInterp.SetOverrideParam('inFileName',inTmpCsvFNm)

myInterp.PrintCRNotice()
myInterp.PrintCmdTree()
myInterp.RunProgram()

# Take the processed CSV from EEMS and convert it to a table
# in a geodatabase (necessary for the join)

outTmpGDBNm = tmpDNm+os.sep+'OutGDB.gdb'
outTmpTblNm=EEMSOutGDBNm+os.sep+'Join_Table'

arcpy.AddMessage('Copying EEMS output CSV to a geodatabase table...\n')
arcpy.CopyRows_management(outTmpCsvNm, outTmpTblNm)

# Join the geodatabase table to the output feature class
arcpy.AddMessage('Joining output table to feature class...\n')
arcpy.JoinField_management(inOutFCNm, 'OBJECTID', outTmpTblNm, 'CSVID')

# Get rid of temporary directory

shutil.rmtree(tmpDNm)
