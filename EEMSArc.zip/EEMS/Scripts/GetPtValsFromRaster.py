################### GetPtValsFromRaster.py ##############################
# From a raster get the value underlying a point and assign the set
# of values to a column in the starting shapefile
########################################################################

import arcpy
import os
import re
from arcpy import env
from arcpy.sa import *

shapefileNm = arcpy.GetParameterAsText(0)
rasterNm = arcpy.GetParameterAsText(1)
newFldNm = arcpy.GetParameterAsText(2)

tmpShapefileNm = re.sub(".shp$", "_tmp.shp", shapefileNm)

arcpy.sa.ExtractValuesToPoints(shapefileNm, rasterNm,tmpShapefileNm)

values = []

for row in arcpy.SearchCursor(tmpShapefileNm):
    values.append(row.getValue('RASTERVALU'))



# create new column name if it doesn't exist

if newFldNm not in arcpy.ListFields(shapefileNm):
    arcpy.AddField_management(shapefileNm, newFldNm, "DOUBLE",10,4)

rows = arcpy.UpdateCursor(shapefileNm)
for row in rows:
    row.setValue(newFldNm,values.pop(0))
    rows.updateRow(row)
#arcpy.Delete_management(tmpShapefileNm)

arcpy.SetParameter(3,shapefileNm)


