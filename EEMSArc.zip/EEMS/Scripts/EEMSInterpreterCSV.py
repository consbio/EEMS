######################################################################
# class EEMSInterpreter
######################################################################
#
# This class interprets an EEMSProgram, taking each EEMSCmd in the
# EEMSProgram and calling the appropriate function with the
# appropriate arguments. An EEMSProgram object and an EEMSCommandRunner
# object must be passed to this class at instantiation.
#
# The EEMSCommandRunner must handle all the file I/O and data manipulation.
# It is where the real EEMS work gets done.
#
# The EEMS language was designed and implemented by, and this script was written by:
#
# Tim Sheehan
# Ecological Modeler
# Conservation Biology Institute
# www.consbio.org
#
# EEMS is based on the functionality of EMDS (http://www.spatial.redlands.edu/emds/)
#
# Contributors to EEMS include:
# Mike Gough, Conservation Biology Institute
# Brendan Ward, Conservation Biology Institute
# Jim Strittholt, Conservation Biology Institute
# Tosha Comendant, Conservation Biology Institute
#
# Revision History
#
# 2014.02.01 - tjs
#
# Completed writing of this class.
#
######################################################################

#from EEMSCmdRunnerTst import EEMSCmdRunner
from EEMSCmdRunnerCSV import EEMSCmdRunner
import EEMSProgram

import arcpy

MODELBUILDER=True
def OutMsg(msg):
    if MODELBUILDER:
        arcpy.AddMessage('\t%s'%(msg))
    else:
        print(msg);
# def OutMsg(msg):

def ProfileTime(outStr):
    OutMsg("%7.3f %s"%(time.clock(),outStr))
# def ProfileTime(outStr):

def RaiseException(errStr):
    try:
        raise Exception(errStr)
    except Exception as inst:
        OutMsg(errStr)
    raise
# end def RaiseException(errStr):


class EEMSInterpreter():

    myProg = None # EEMSProgram object
    myCmdRunner = None # EEMSCmdRunner object
    verbose = True

    # default values for optional params without values
    dfltOptnlParamVals = {} 

    # values to override required params. Be careful!
    paramOverrideVals = {} 

    def __init__(self,EEMSProgFNm):
        self.myProg = EEMSProgram.EEMSProgram(EEMSProgFNm)
        self.myProg.SetCrntCmdToFirst() # start at beginning
        self.myCmdRunner = EEMSCmdRunner()

    def GetCmdTreeAsString(self):
        return self.myProg.GetCmdTreeAsString()

    def SetDfltOptionalParam(self,TorF):
        self.verbose = TorF

    def SetDfltOptionalParam(self,paramNm,paramVal):
            self.dfltOptnlParamVals[paramNm] = paramVal

    def SetOverrideParam(self,paramNm,paramVal):
            self.paramOverrideVals[paramNm] = paramVal
            OutMsg('Overrides: %s'%(','.join(self.paramOverrideVals.keys())))

    def RunProgram(self):
        
        if self.verbose: print 'Running Commands:'

        while True: # work loop over all commands
            
            if self.verbose:
                print '  '+self.myProg.GetCrntCmdString()

            cmdNm = self.myProg.GetCrntCmdName()

            cmdParams = {} # parameters that will be used in command

            # Set values for optional parameters
            for paramNm in self.myProg.GetOptionalParamNmsForCrntCmd():
                if self.myProg.CrntHasParam(paramNm):
                    cmdParams[paramNm] = self.myProg.GetParamFromCrntCmd(paramNm)
                elif paramNm in self.dfltOptnlParamVals.keys():
                    cmdParams[paramNm] = self.dfltOptnlParamVals[paramNm]
                else:
                    cmdParams[paramNm] = 'NONE'

            # Do overrides for required parameters

            OutMsg('02'+','.join(self.myProg.GetParamNmsFromCrntCmd()))
            
            for paramNm in self.myProg.GetParamNmsFromCrntCmd():
                OutMsg('10'+paramNm)
                OutMsg('20'+','.join(self.paramOverrideVals.keys()))
                OutMsg('30'+','.join(cmdParams.keys()))

                # if (paramNm in self.paramOverrideVals.keys() and
                #     paramNm in cmdParams.keys()):
                if paramNm in self.paramOverrideVals.keys():
                    OutMsg('40 yes override')
                    cmdParams[paramNm] = self.paramOverrideVals[paramNm]
                else:
                    cmdParams[paramNm] = self.myProg.GetParamFromCrntCmd(paramNm)

            if cmdNm == 'READ':
                self.myCmdRunner.Read(
                    cmdParams['InFileName'],
                    cmdParams['InFieldName'],
                    cmdParams['OutFileName'],
                    )

            elif cmdNm == 'READMULTI':
                self.myCmdRunner.ReadMulti(
                    cmdParams['InFileName'],
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    )

            elif cmdNm == 'CVTTOFUZZY':
                self.myCmdRunner.CvtToFuzzy(
                    cmdParams['InFieldName'],
                    cmdParams['TrueThreshold'],
                    cmdParams['FalseThreshold'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
    
            elif cmdNm == 'CVTTOFUZZYCURVE':
                self.myCmdRunner.CvtToFuzzyCurve(
                    cmdParams['InFieldName'],
                    cmdParams['RawValues'],
                    cmdParams['FuzzyValues'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
    
            elif cmdNm == 'COPYFIELD':
                self.myCmdRunner.CopyField(
                    cmdParams['InFieldName'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )

            elif cmdNm == 'NOT':
                self.myCmdRunner.FuzzyNot(
                    cmdParams['InFieldName'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )

            elif cmdNm == 'OR':
                self.myCmdRunner.FuzzyOr(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'AND':
                self.myCmdRunner.FuzzyAnd(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'EMDSAND':
                self.myCmdRunner.FuzzyEMDSAnd(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'ORNEG':
                self.myCmdRunner.FuzzyOrNeg(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'XOR':
                self.myCmdRunner.FuzzyXOr(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )

            elif cmdNm == 'SUM':
                self.myCmdRunner.SumFlds(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'MIN':
                self.myCmdRunner.MinFlds(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'MAX':
                self.myCmdRunner.MaxFlds(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'MEAN':
                self.myCmdRunner.MeanFlds(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )

            elif cmdNm == 'UNION':
                self.myCmdRunner.FuzzyUnion(
                    cmdParams['InFieldNames'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'DIF':
                self.myCmdRunner.DifFlds(
                    cmdParams['StartingFieldName'],
                    cmdParams['ToSubtractFieldName'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'SELECTEDUNION':
                self.myCmdRunner.FuzzySelectedUnion(
                    cmdParams['InFieldNames'],
                    cmdParams['TruestOrFalsest'],
                    cmdParams['NumberToConsider'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'WTDUNION':
                self.myCmdRunner.FuzzyWeightedUnion(
                    cmdParams['InFieldNames'],
                    cmdParams['Weights'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'WTDEMDSAND':
                self.myCmdRunner.FuzzyEMDSWeightedAnd(
                    cmdParams['InFieldNames'],
                    cmdParams['Weights'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'WTDMEAN':
                self.myCmdRunner.WeightedMean(
                    cmdParams['InFieldNames'],
                    cmdParams['Weights'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            elif cmdNm == 'WTDSUM':
                self.myCmdRunner.WeightedSum(
                    cmdParams['InFieldNames'],
                    cmdParams['Weights'],
                    cmdParams['OutFileName'],
                    self.myProg.GetCrntResultName()
                    )
                
            else:
                raise Exception(
                    'ERROR: Unable to interpret command:\n'+
                    '  %s'%self.myProg.GetCrntCmdString()
                    )
            
            # if cmdNm == 'READ'...elif...else:
            
            # exit work loop if there is not another command to process
            if not self.myProg.NextCmd():
                break;
        
        # while True

        if self.verbose: print '  Finish()'
        self.myCmdRunner.Finish() # finish final tasks

    # def RunProgram(self):
    
    def PrintCmdTree(self):
        print self.myProg.GetCmdTreeAsString()

# class EEMSInerpreter(EEMSCmdRunner):
