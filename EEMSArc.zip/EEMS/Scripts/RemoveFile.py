import arcpy
import re
import os

fileNm = arcpy.GetParameterAsText(0)

result = 'False'

if os.path.isfile(fileNm):
    result = 'True'
    os.remove(fileNm)

arcpy.SetParameter(1,result)
    
