from __future__ import division
import arcpy
import random
import csv
import time
import re
import os
from os import path
from arcpy import env
import shutil
import tempfile

from EEMSBasePackage import EEMSUtils as EEMSUtils
#from EEMSInterpreterCSV import EEMSInterpreter
from EEMSCSV import EEMSCmdRunner
from EEMSBasePackage import EEMSInterpreter

########################################################################
# Globals for control, etc
DEBUG = False
MODELBUILDER = True

MinForFuzzyLimit = -9999
MaxForFuzzyLimit = 9999
NullFuzzyValue = 0
########################################################################

def OutMsg(msg):
    if MODELBUILDER:
        arcpy.AddMessage('\t%s'%(msg))
    else:
        print(msg);
# def OutMsg(msg):

def RaiseException(errStr):
    try:
        raise Exception(errStr)
    except Exception as inst:
        OutMsg(errStr)
    raise
# end def RaiseException(errStr):

def PrintEEMSHdr():
    OutMsg('+------------------------------------------------------------------+')
    OutMsg('|                                                                  |')
    OutMsg('|         EEMS - Environmental Evaluation Modeling System          |')
    OutMsg('|                                                                  |')
    OutMsg('| Implementation for ArcMap Model Builder                          |')
    OutMsg('| Version: 2.0 Alpha                                               |')
    OutMsg('|                                                                  |')
    OutMsg('+------------------------------------------------------------------+')
# def PrintEEMSHdr:

########################################################################
# Processing Starts HERE
########################################################################
start_time = time.time()

eemsUtils = EEMSUtils()

PrintEEMSHdr()

inTbl = arcpy.GetParameterAsText(0)
outFolder = arcpy.GetParameterAsText(1)
outTblNm = arcpy.GetParameterAsText(2)
cmdFileNm = arcpy.GetParameterAsText(3)

# For the Model Logic Check tool
if outTblNm == "CHECKLOGIC":
    myEEMSProgram = EEMSProgram.EEMSProgram(cmdFileNm)
    OutMsg(myEEMSProgram.GetCmdTreeAsString())
    exit(0)
# if arcpy.GetParameterAsText(0) == "CHECKLOGIC":

outTbl = outFolder+os.sep+outTblNm

if inTbl == outTbl:
    RaiseException("Input and Output tables cannot be the same: %s\n"%(inTbl))

tmpDir = tempfile.mkdtemp()

OutMsg('Creating results feature class...')
OutMsg('  Copying {} to {}/{}'.format(inTbl,outFolder,outTblNm))

arcpy.FeatureClassToFeatureClass_conversion(inTbl, outFolder, outTblNm,"#","#","#" )

# Delete fields from the output feature class
dropFields=[]
fields=arcpy.ListFields(outTbl)
for field in fields:

    #if field.name!='Shape'and field.name !='OBJECTID' and field.name != "Shape_Length" and field.name != "Shape_Area":

    if field.name not in ['Shape','OBJECTID','Shape_Length','Shape_Area']:
        dropFields.append(field.name)

OutMsg('  Deleting Fields:'.format(','.join(dropFields)))

arcpy.DeleteField_management(outTbl, dropFields)

# Create the CSV File
OutMsg('Exporting feature class to CSV...')

EEMSCSVFNm=tmpDir+os.sep+"reportingUnits.csv"
OutMsg('  EEMSCSVFNm: {}'.format(EEMSCSVFNm))

# Add the fields for EEMS fields
file=open(EEMSCSVFNm, 'wb')
rows = arcpy.SearchCursor(inTbl)
csvFile = csv.writer(file) #output csv
fieldnames = [f.name for f in arcpy.ListFields(inTbl)]

OutMsg('  Adding EEMS fields: {}'.format(','.join(fieldnames)))

allRows = []
for row in rows:
    rowlist = []
    for field in fieldnames:
        rowlist.append(row.getValue(field))
    allRows.append(rowlist)

fieldnames[0]='CSVID'

csvFile.writerow(fieldnames)
for row in allRows:
    csvFile.writerow(row)

file.close()

OutMsg('Preparing EEMS command file...')

# Add the line to the EEMS command file that will read and
# write the CSVID (match of object ID) to the result file
tmpOutF = open(cmdFileNm,'a')
tmpOutF.write(
    '{}(InFileName = {},InFieldName = {},OutFileName = {})'.format(
        'READ',EEMSCSVFNm,'CSVID','EEMSArcOutDflt'
        )
    )
tmpOutF.close()

# Optimize EEMS read commands and create command interpreter
tmpCmdFNm = tmpDir+os.sep+'TmpCmds.eem'

OutMsg(' Command file name: '+ cmdFileNm)
OutMsg(' Temp command file name: '+ tmpCmdFNm)
OutMsg(' Optimizing command file...')

eemsUtils.OptimizeEEMSReading(cmdFileNm,tmpCmdFNm)

OutMsg('Running EEMS...')

myCmdInterp = EEMSInterpreter(tmpCmdFNm,EEMSCmdRunner())

OutMsg('  Overiding output IO file names...')

# Substitute the name of the csv file for the name of the input file
myCmdInterp.SetOverrideParam('InFileName',EEMSCSVFNm)
myCmdInterp.SetOverrideParam('OutFileName',EEMSCSVFNm)

OutMsg('  Running EEMS...')

# Run EEMS program
myCmdInterp.RunProgram()

# Copy csv back to input table

# Create a geodatabase with a temporary table
# load the csv into that
# join that to the output feature class

OutMsg('Creating results feature class...')

tmpGDB = arcpy.CreateFileGDB_management(tmpDir,'tmp.gdb')
tmpOutTbl = tmpDir+os.sep+'tmp.gdb'+os.sep+'Join_Table'
OutMsg('  Creating temporary table {}'.format(tmpOutTbl))
OutMsg('  Copying rows...')

arcpy.CopyRows_management(EEMSCSVFNm,tmpOutTbl)

# Delete extraneous fields from the table.
deleteTableFields = ['Shape', 'Shape_Length', 'Shape_Area']
OutMsg('  Deleting extraneous fields {}'.format(','.join(deleteTableFields)))
arcpy.DeleteField_management(tmpOutTbl, deleteTableFields)

OutMsg('Populating results feature class...')
OutMsg('  Joining {} and {}'.format(outTbl,tmpOutTbl))
# Join the geodatabase table to the output feature class

arcpy.JoinField_management(outTbl, 'OBJECTID', tmpOutTbl, 'CSVID')
OutMsg('  Deleting temporary column CSVID')
arcpy.DeleteField_management(outTbl, ['CSVID'])

# Remove temp directory and its contents
OutMsg('Deleting temporary data...')
OutMsg('  Deleting {}'.format(tmpDir))

shutil.rmtree(tmpDir)

elapsed_time = time.time() - start_time
OutMsg('Done')
OutMsg('Elapsed Time: ' + str(elapsed_time))

# bob's your uncle!
