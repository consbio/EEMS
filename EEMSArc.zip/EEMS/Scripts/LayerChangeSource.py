# change the source of a layer file

import re,arcpy,os,traceback

########################################################################
# Globals for control, etc
DEBUG = True
MODELBUILDER = True
########################################################################

def RaiseException(errStr):
    try:
        raise Exception(errStr)
    except Exception as inst:
        print inst
    raise

def OutMsg(msg):
    if MODELBUILDER:
        arcpy.AddMessage('\t%s'%(msg))
    else:
        print(msg);
# def OutMsg(msg):

inFNm = arcpy.GetParameterAsText(0)
newSrcNm = arcpy.GetParameterAsText(1)
outDirNm = arcpy.GetParameterAsText(2)
outFNm = arcpy.GetParameterAsText(3)

outFPath = outDirNm + '\\' + re.sub('\.lyr','',outFNm) + '.lyr'

newWorkPath = r'F:\TimArcTools\Data\SOD_C_TI_4KM.gdb'


lyrFile = arcpy.mapping.Layer(inFNm)
for lyr in arcpy.mapping.ListLayers(lyrFile):
    OutMsg('%s: *%s*'%('lyr.longName',lyr.longName))
    OutMsg('  %s: *%s*'%('lyr.name.lower()',lyr.name.lower()))
    OutMsg('  %s: *%s*'%('lyr.isGroupLayer',lyr.isGroupLayer))
    OutMsg('  %s: *%s*'%('lyr.isFeatureLayer',lyr.isFeatureLayer))
    if not lyr.isGroupLayer:
        OutMsg('  %s: *%s*'%('lyr.datasetName',lyr.datasetName))
        OutMsg('  %s: *%s*'%('lyr.dataSource',lyr.dataSource))
        OutMsg('  %s: *%s*'%('lyr.description',lyr.description))
        OutMsg('  %s: *%s*'%('lyr.name',lyr.name))

    if lyr.supports('DATASOURCE'):
        OutMsg('  %s: *%s*'%('newWorkPath',newWorkPath))

        # This stuff does not appear to work with layers of shapefiles
        #lyr.replaceDataSource(newSrcNm,'SHAPEFILE_WORKSPACE','SOD_C_TI_4KM')
        #lyr.replaceDataSource(newSrcNm,'NONE','SOD_C_TI_HUC5')
        #lyr.replaceDataSource(outDirNm,'SHAPEFILE_WORKSPACE','SOD_C_TI_HUC5A.shp')
        #lyr.replaceDataSource(outDirNm,'NONE','SOD_C_TI_HUC5A.shp')
        # This works
        #lyr.findAndReplaceWorkspacePath(outDirNm,outDirNm)

        lyr.replaceDataSource(newWorkPath,'FILEGDB_WORKSPACE','SOD_C_TI_4KM_poly')

lyrFile.saveACopy(outFPath)

del lyr
del lyrFile

