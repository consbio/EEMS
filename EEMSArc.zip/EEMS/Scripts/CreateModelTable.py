########################################################################
# CreateModelInputTable.py

# By Tim Sheehan
# Conservation Biology Institute
# www.consbio.org

# For use in the EEMS for ArcMap modeling system

# This script takes a table, which should be an Arc Table, Feature Class,
# or Shapefile, copies it, and deletes all but the user specified
# fields and those fields necessary in the input object.

# In EEMS, the table resulting from this should contain the needed
# inputs for a model (the EEMS Read commands)

# Development History
# 2012.02.24 - Debug and finalize for testing. Script interface
#  using this is EEMS CreateModelTable

########################################################################

import arcpy
import os
import re
from arcpy import env

########################################################################
# Globals and control
MODELBUILDER = True
########################################################################

def OutMsg(msg):
    if MODELBUILDER:
        arcpy.AddMessage('\t%s'%(msg))
    else:
        print(msg);
# def OutMsg(msg):

# Globals for housekeeping
ScriptName = 'CreateModelTable.py'


def RaiseException(errStr):
    try:
        raise Exception(errStr)
    except Exception as inst:
        print inst
    raise
# end def RaiseException(errStr):

def CreateTheTbl(inTblNm, outTbl,keepFldLst):

    if arcpy.Exists(outTbl):
        arcpy.Delete_management(outTbl)

    OutMsg('Creating output feature class %s'%(outTbl))

    arcpy.Copy_management(inTblNm,outTbl)

    # delete any fields besides joinFldNm

    deleteFlds=[]

    # Fields that are illegal to delete

    mustHaveFldLst = ['Shape_Length','Shape_Area','Shape_Leng']

    
    for fld in arcpy.ListFields(outTbl):
        if fld.type in ['OID','Geometry']:
            mustHaveFldLst.append(fld.name)

    arcpy.AddMessage('\tDeleting Fields from %s:'%(outTbl))

    for fld in arcpy.ListFields(outTbl):
        if fld.name not in keepFldLst + mustHaveFldLst:
            OutMsg('\t%s %s'%(fld.name, fld.type))
            deleteFlds.append(fld.name)
#            arcpy.DeleteField_management(outTbl,[fld.name])

    if deleteFlds:
        arcpy.DeleteField_management(outTbl,deleteFlds)

# def CreateTheTbl():

########################################################################
# Processing starts here
########################################################################

runCreateTheTbl = arcpy.GetParameterAsText(0)
inTblNm    = arcpy.GetParameterAsText(1)
keepFldNms = arcpy.GetParameterAsText(2)
outTblDirNm   = arcpy.GetParameterAsText(3)
outTblNm   = arcpy.GetParameterAsText(4)

# Insure output shapefile has correct extension
if re.search('.shp$',inTblNm):
    outTblNm = re.sub('.shp$', '', outTblNm)
    outTblNm = outTblNm + '.shp'

outTbl = outTblDirNm + '\\' + outTblNm

keepFldLst = keepFldNms.rsplit(';')

OutMsg('Keeping Fields:')

for fld in keepFldLst:
    OutMsg('\t%s'%(fld))

if runCreateTheTbl == 'True':
    OutMsg('%s: Creating new output table %s'%(ScriptName,outTbl))    
    CreateTheTbl(inTblNm,outTbl,keepFldLst)
else:
    OutMsg('%s: Not making new version of output table %s'%(ScriptName,outTbl))    
# if runCreateTheTbl == 'True':

arcpy.SetParameter(5,outTbl)

