# change the source of a layer file

import re,arcpy,os,traceback

########################################################################
# Globals for control, etc
DEBUG = True
MODELBUILDER = True
########################################################################

def RaiseException(errStr):
    try:
        raise Exception(errStr)
    except Exception as inst:
        print inst
    raise

def OutMsg(msg):
    if MODELBUILDER:
        arcpy.AddMessage('\t%s'%(msg))
    else:
        print(msg);
# def OutMsg(msg):

inFNm = arcpy.GetParameterAsText(0)
newSrcPath = arcpy.GetParameterAsText(1)
outDir = arcpy.GetParameterAsText(2)
outFNm = arcpy.GetParameterAsText(3)

mxd = arcpy.mapping.MapDocument(inFNm)

newWorkPath = os.path.dirname(newSrcPath)
newWorkFeature = os.path.basename(newSrcPath)

outFPath = outDirNm + '\\' + re.sub('\.lyr','',outFNm) + '.lyr'

for lyr in arcpy.mapping.ListLayers(mxd):
    OutMsg('%s: *%s*'%('lyr.longName',lyr.longName))
    OutMsg('  %s: *%s*'%('lyr.name.lower()',lyr.name.lower()))
    OutMsg('  %s: *%s*'%('lyr.isGroupLayer',lyr.isGroupLayer))
    OutMsg('  %s: *%s*'%('lyr.isFeatureLayer',lyr.isFeatureLayer))
    if not lyr.isGroupLayer:
        OutMsg('  %s: *%s*'%('lyr.datasetName',lyr.datasetName))
        OutMsg('  %s: *%s*'%('lyr.dataSource',lyr.dataSource))
        OutMsg('  %s: *%s*'%('lyr.description',lyr.description))
        OutMsg('  %s: *%s*'%('lyr.name',lyr.name))

    if lyr.supports('DATASOURCE'):
        OutMsg('  %s: *%s*'%('newWorkPath',newWorkPath))
        lyr.replaceDataSource(newWorkPath,'FILEGDB_WORKSPACE',)

lyrFile.saveACopy(outFPath)

del lyr
del lyrFile

