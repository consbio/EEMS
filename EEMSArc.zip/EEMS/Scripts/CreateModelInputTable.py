########################################################################
# CreateModelInputTable.py

# By Tim Sheehan
# Conservation Biology Institute
# www.consbio.org

# For use in the EEMS for ArcMap modeling system

# This script takes a table, which should be an Arc Table, Feature Class,
# or Shapefile, copies it, and deletes all but the user specified
# fields and those fields necessary in the input object.

# In EEMS, the table resulting from this should contain the needed
# inputs for a model (the EEMS Read commands)

# Development 

########################################################################

import arcpy
import os
from arcpy, import env

########################################################################
# Globals and control
MODELBUILDER = True
########################################################################

def OutMsg(msg):
    if MODELBUILDER:
        arcpy.AddMessage('\t%s'%(msg))
    else:
        print(msg);
# def OutMsg(msg):

# Globals for housekeeping
ScriptName = 'CreateModelTable.py'


def RaiseException(errStr):
    try:
        raise Exception(errStr)
    except Exception as inst:
        print inst
    raise
# end def RaiseException(errStr):

def CreateTheTable(inTblNm, outTbl,keepFldLst):

    if arcpy.Exists(outTbl):
        arcpy.Delete_management(outTbl)

    arcpy.AddMessage("\tCreating output table %s"%(outTbl))

    arcpy.CopyRows_management(inTblNm,outTbl)

    # delete any fields besides joinFldNm

    deleteFlds=[]

    arcpy.AddMessage('\tDeleting Fields from %s:'%(outTbl))
    
    for fld in arcpy.ListFields(outTbl):
        if fld.name not in keepFldLst:
            arcpy.AddMessage('\t\t%s'%(fld.name))
            deleteFlds.append(fld.name)

    if deleteFlds:
        arcpy.DeleteField_management(outTbl,deleteFlds)

# def CreateTheTable():

def CreateTheFC(inFCNm, outFC,keepFldLst):

    if arcpy.Exists(outFC):
        arcpy.Delete_management(outFC)

    OutMsg("Creating output feature class %s"%(outFC))

    arcpy.Copy_management(inFCNm,outFC)

    # delete any fields besides joinFldNm

    deleteFlds=[]

    # Fields that are illegal to delete

    mustHaveFldLst = ['Shape_Length','Shape_Area','Shape_Leng']

    
    for fld in arcpy.ListFields(outFC):
        if fld.type in ['OID','Geometry']:
            mustHaveFldLst.append(fld.name)

    arcpy.AddMessage('\tDeleting Fields from %s:'%(outFC))

    for fld in arcpy.ListFields(outFC):
        if fld.name not in keepFldLst + mustHaveFldLst:
            OutMsg('\t%s %s'%(fld.name, fld.type))
            deleteFlds.append(fld.name)
#            arcpy.DeleteField_management(outFC,[fld.name])

    if deleteFlds:
        arcpy.DeleteField_management(outFC,deleteFlds)

# def CreateTheFC():

########################################################################
# Processing start here
########################################################################

makeFC    = arcpy.GetParameterAsText(0)
inFCNm    = arcpy.GetParameterAsText(1)
keepFldNms = arcpy.GetParameterAsText(2)
outGDBNm   = arcpy.GetParameterAsText(3)
outFCNm   = arcpy.GetParameterAsText(4)

for i in range(5):
    OutMsg(arcpy.GetParameterAsText(i))

outFC = outGDBNm + '\\' + outFCNm

keepFldLst = keepFldNms.rsplit(';')
keepFldLst.append('OBJECTID')

arcpy.AddMessage('\tKeeping Fields:')

for fld in keepFldLst:
    arcpy.AddMessage('\t\t%s'%(fld))

if makeFC == 'True':
    CreateTheFC(inFCNm,outFC,keepFldLst)
else:
    arcpy.AddMessage('\t%s: Not making new version of output feature class %s'%(ScriptName,outFC))    
# if makeTbl == 'True':

RaiseException('Ha')

arcpy.SetParameter(5,outFC)

