Tim Sheehan -- 2016.02.15

This directory contains an Arc toolbox directory with all the commands for Arc EEMS
as well as a script directory containing what should be all the python scripts needed
for the Arc EEMS commands. The toolbox was created with relative path names, so if
Arc is working correctly, you should be able to use the tools in the toolbox without
changing their properties.

This version EEMS for Arc was developed and tested under ArcMap 10.1 (Build 3143).

Good luck!
